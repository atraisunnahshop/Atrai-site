# আত্রাই সুন্নাহ্ শপ — atraisunnahshop.com

**শুরু করতে `SETUP-GUIDE.md` পড়ুন।** `AUDIT.md` (কী পাওয়া গেল), `CHANGES.md` (কী বদলাল), `TEST-REPORT.md` (কী পরীক্ষা হলো/হয়নি)।

- ডিপ্লয় হয় শুধু `public/`। অ্যাডমিন: `https://atraisunnahshop.com/ams-8ixfqfxau0` (গোপন)।
- ডাটাবেস রুলস: প্রথমে `database.rules.phase1-now.json`; অর্ডার ব্যবস্থা পরীক্ষা সফল হলে `database.rules.phase2-strict.json`।
- কোনো secret কখনো কোডে/চ্যাটে নয় — শুধু Netlify Environment Variables-এ।

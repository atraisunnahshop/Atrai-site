// অনলাইন পেমেন্ট শুরু (কাঠামো)। প্রোভাইডারের adapter না লেখা পর্যন্ত 501 ফেরত দেয়।
// চালু করতে: ১) providers/<নাম>.js লিখুন ২) নিচের adapters-এ যোগ করুন ৩) env: PAYMENT_PROVIDER ও প্রোভাইডারের কী
// ৪) index.html-এ PAYMENT_API = "/.netlify/functions/payment-init" ও সেটিংসে "অনলাইন পেমেন্ট" চালু করুন।
const { init, admin, json } = require("./_shared");
const adapters = {
  // sslcommerz: require("./providers/sslcommerz"),   // createSession({ order, urls }) → paymentPageUrl
};
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { ok: false, error: "Method not allowed" });
  const provider = process.env.PAYMENT_PROVIDER;
  if (!provider || !adapters[provider]) return json(501, { ok: false, error: "অনলাইন পেমেন্ট এখনো কনফিগার করা হয়নি" });
  try {
    init();
    const body = JSON.parse(event.body || "{}");
    const snap = await admin.database().ref("orders/" + String(body.orderId || "")).once("value"), order = snap.val();
    if (!order || order.payment?.method !== "online" || order.payment?.verified) return json(400, { ok: false, error: "অর্ডার পাওয়া যায়নি" });
    if (String(order.customer.phone).slice(-4) !== String(body.phoneTail || "")) return json(403, { ok: false, error: "যাচাই হয়নি" });
    const base = process.env.SITE_URL || "";
    const url = await adapters[provider].createSession({ order, urls: { success: base + "/?paid=1", fail: base + "/?paid=0", webhook: base + "/.netlify/functions/payment-webhook" } });
    return json(200, { ok: true, url });
  } catch (e) { console.error(e); return json(500, { ok: false, error: "পেমেন্ট শুরু করা যায়নি" }); }
};

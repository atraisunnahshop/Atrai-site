// অর্ডার কনফার্মে SMS (কাঠামো)। শুধু অ্যাডমিনের লগইন টোকেন থাকলে চলে। adapter না লেখা পর্যন্ত 501।
const { init, admin, json } = require("./_shared");
const adapters = {
  // bulksmsbd: require("./providers/bulksmsbd"),   // send({ to, text })
};
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { ok: false, error: "Method not allowed" });
  const provider = process.env.SMS_PROVIDER;
  if (!provider || !adapters[provider]) return json(501, { ok: false, error: "SMS প্রোভাইডার কনফিগার করা হয়নি" });
  try {
    init();
    const tok = (event.headers.authorization || "").replace(/^Bearer /, ""), u = await admin.auth().verifyIdToken(tok);
    if ((u.email || "").toLowerCase() !== (process.env.ADMIN_EMAIL || "").toLowerCase()) return json(403, { ok: false, error: "অনুমতি নেই" });
    const { orderId, broadcast, text: bText } = JSON.parse(event.body || "{}"), db = admin.database();
    if (broadcast) {  // শুধু সম্মতি দেওয়া ও opt-out না করা কন্টাক্টে (ডাটাবেস থেকে নেওয়া, ক্লায়েন্টের তালিকা বিশ্বাস করা হয় না)
      const cs = Object.values((await db.ref("contacts").once("value")).val() || {}).filter(c => c.consent === true && !c.optOut).slice(0, 500);
      let sent = 0; for (const c of cs) { try { await adapters[provider].send({ to: "88" + c.phone, text: String(bText || "").replace(/\{name\}/g, c.name || "").slice(0, 300) }); sent++; } catch (e) { /* পরেরটি */ } }
      return json(200, { ok: true, sent });
    }
    const [os, ss] = await Promise.all([db.ref("orders/" + orderId).once("value"), db.ref("settings").once("value")]), o = os.val(), s = ss.val() || {};
    if (!o || !(s.smsOn === true || s.smsOn === "true")) return json(400, { ok: false, error: "SMS চালু নেই বা অর্ডার নেই" });
    const vars = { customer_name: o.customer.name, order_id: o.id, total_price: "৳" + o.grandTotal, track_url: process.env.SITE_URL || "", shop_name: "আত্রাই সুন্নাহ্ শপ" };
    const text = String(s.smsTpl || "").replace(/\{(\w+)\}/g, (m, k) => (k in vars ? vars[k] : m));
    await adapters[provider].send({ to: "88" + o.customer.phone, text });
    return json(200, { ok: true });
  } catch (e) { console.error(e); return json(500, { ok: false, error: "SMS পাঠানো যায়নি" }); }
};

// পেমেন্ট সফল হলে প্রোভাইডার এই ঠিকানায় জানায় (কাঠামো)। adapter.verify অবশ্যই প্রোভাইডারের স্বাক্ষর/সার্ভার-টু-সার্ভার যাচাই করবে।
const { init, admin, json } = require("./_shared");
const adapters = {
  // sslcommerz: require("./providers/sslcommerz"),   // verify(event) → { orderId, paid, amount, txnId }
};
exports.handler = async (event) => {
  const provider = process.env.PAYMENT_PROVIDER;
  if (!provider || !adapters[provider]) return json(501, { ok: false, error: "not configured" });
  try {
    init();
    const r = await adapters[provider].verify(event);
    if (!r || !r.paid) return json(200, { ok: true });
    const db = admin.database(), snap = await db.ref("orders/" + r.orderId).once("value"), order = snap.val();
    if (!order || Number(r.amount) !== Number(order.grandTotal)) return json(400, { ok: false, error: "amount mismatch" });
    await db.ref("orders/" + r.orderId + "/payment").update({ verified: true, trxId: String(r.txnId || ""), advance: order.grandTotal, paidAt: Date.now() });
    return json(200, { ok: true });
  } catch (e) { console.error(e); return json(500, { ok: false }); }
};

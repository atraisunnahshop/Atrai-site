// অর্ডার ট্র্যাকিং: মোবাইল নম্বর দিলে শুধু প্রয়োজনীয় তথ্য ফেরত (নাম, ঠিকানা, পণ্যের তালিকা, মোট বিল নয়)
const admin = require("firebase-admin");
const crypto = require("crypto");
const SEC = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer" };
const json = (code, body) => ({ statusCode: code, headers: SEC, body: JSON.stringify(body) });
const BN = "০১২৩৪৫৬৭৮৯"; const toEn = s => String(s ?? "").replace(/[০-৯]/g, d => BN.indexOf(d));
function init() {
  if (admin.apps.length) return;
  admin.initializeApp({ credential: admin.credential.cert({ projectId: process.env.FIREBASE_PROJECT_ID, clientEmail: process.env.FIREBASE_CLIENT_EMAIL, privateKey: (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n") }), databaseURL: process.env.FIREBASE_DATABASE_URL });
}
const hits = new Map();
function limited(ip) { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 600000); a.push(now); hits.set(ip, a); return a.length > 20; }
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { ok: false });
  const allowed = process.env.ALLOWED_ORIGIN; if (allowed && event.headers.origin && event.headers.origin !== allowed) return json(403, { ok: false });
  const ip = (event.headers["x-nf-client-connection-ip"] || event.headers["x-forwarded-for"] || "").split(",")[0].trim() || "na";
  if (limited(ip)) return json(429, { ok: false, error: "অনেকবার চেষ্টা হয়েছে" });
  let body; try { body = JSON.parse(event.body || "{}"); } catch (e) { return json(400, { ok: false }); }
  const q = toEn(body.q ?? body.phone).trim().toUpperCase().replace(/\s+/g, "");
  const phone = q.replace(/\D/g, "").replace(/^88/, "");
  const mode = /^01[3-9]\d{8}$/.test(phone) ? "phone" : /^ATR-\d{6}-[A-Z0-9]{4,8}$/.test(q) ? "order" : /^[A-Z0-9-]{5,40}$/.test(q) ? "courier" : "";
  if (!mode) return json(400, { ok: false, error: "নম্বর সঠিক নয়" });
  try {
    init(); const ref = admin.database().ref("tracking"); let rows = [];
    if (mode === "order") { const v = (await ref.child(q).once("value")).val(); if (v) rows = [[q, v]]; }
    else if (mode === "phone") { const hash = crypto.createHash("sha256").update("ass:" + phone).digest("hex"); rows = Object.entries((await ref.orderByChild("phoneHash").equalTo(hash).limitToLast(10).once("value")).val() || {}); }
    else { rows = Object.entries((await ref.orderByChild("trackingNo").equalTo(q).limitToLast(5).once("value")).val() || {}); }
    // শুধু প্রয়োজনীয় তথ্য: অবস্থা, সময়, কুরিয়ার — নাম/ঠিকানা/ফোন/পণ্য/মোট বিল নয়
    const orders = rows.map(([id, t]) => ({ id, status: t.status, createdAt: t.createdAt, updatedAt: t.updatedAt, courier: t.courier || "", trackingNo: t.trackingNo || "" })).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return json(200, { ok: true, orders });
  } catch (e) { console.error("track-order", e); return json(500, { ok: false }); }
};

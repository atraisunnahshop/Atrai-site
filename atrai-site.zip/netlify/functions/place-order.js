// Netlify Function: সার্ভারে দাম/স্টক/কুপন যাচাই করে অর্ডার সেভ করে।
// ক্লায়েন্টের পাঠানো দাম কখনো বিশ্বাস করা হয় না।
const admin = require("firebase-admin");
const crypto = require("crypto");

const BN = "০১২৩৪৫৬৭৮৯";
const toEn = s => String(s ?? "").replace(/[০-৯]/g, d => BN.indexOf(d));
const num = s => { const n = parseFloat(toEn(s).replace(/[^\d.]/g, "")); return isNaN(n) ? 0 : n; };
const clean = (s, max) => String(s ?? "").replace(/[\u0000-\u001f<>]/g, " ").trim().slice(0, max);
const SEC = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer" };
const json = (code, body, extra) => ({ statusCode: code, headers: { ...SEC, ...(extra || {}) }, body: JSON.stringify(body) });
const corsHeaders = (event) => { const o = process.env.ALLOWED_ORIGIN; return o && event.headers.origin === o ? { "Access-Control-Allow-Origin": o, "Vary": "Origin", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" } : { "Vary": "Origin" }; };

function init() {
  if (admin.apps.length) return;
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
    }),
    databaseURL: process.env.FIREBASE_DATABASE_URL,
  });
}

// সহজ রেট লিমিট (সার্ভারলেস ইনস্ট্যান্স ভেদে সীমিত কার্যকর)
const hits = new Map();
function limited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 600000);
  arr.push(now); hits.set(ip, arr); return arr.length > 6;
}

const finalPrice = v => (v.discountPrice && Number(v.discountPrice) < Number(v.price)) ? Number(v.discountPrice) : Number(v.price);
const variantsOf = p => (p.variants && p.variants.length) ? p.variants : [{ size: p.size || "১টি", price: p.price, discountPrice: p.discountPrice }];
const hasQty = p => p.stockQty !== undefined && p.stockQty !== null && p.stockQty !== "";
const available = p => p.inStock !== false && (!hasQty(p) || Number(p.stockQty) > 0);

function couponDiscount(c, sub) {
  if (!c) return { amt: 0 };
  if (c.active === false) throw new Error("কুপনটি বর্তমানে বন্ধ");
  if (c.expires && new Date(c.expires + "T23:59:59").getTime() < Date.now()) throw new Error("কুপনের মেয়াদ শেষ");
  if (num(c.minOrder) && sub < num(c.minOrder)) throw new Error("কুপনের ন্যূনতম অর্ডার পূরণ হয়নি");
  let amt = c.type === "flat" ? num(c.value) : Math.round(sub * num(c.value) / 100);
  if (c.type !== "flat" && num(c.maxDiscount)) amt = Math.min(amt, num(c.maxDiscount));
  return { amt: Math.min(amt, sub) };
}

function makeId() {
  const d = new Date(), pad = n => String(n).padStart(2, "0"), A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", r = crypto.randomBytes(6);
  return "ATR-" + String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) + "-" + [...r].map(x => A[x % A.length]).join("");
}

exports.buildOrder = function buildOrder(body, products, settings, coupons) {
  if (!(settings.termsOn === false || settings.termsOn === "false") && body.terms !== true) throw new Error("শর্তাবলিতে সম্মতি দিন");
  const c = body.customer || {};
  const name = clean(c.name, 100), address = clean(c.address, 300), note = clean(c.note, 300);
  const phone = toEn(c.phone).replace(/\D/g, "").replace(/^88/, "");
  if (name.length < 2) throw new Error("নাম সঠিক নয়");
  if (!/^01[3-9]\d{8}$/.test(phone)) throw new Error("মোবাইল নম্বর সঠিক নয়");
  if (address.length < 5) throw new Error("ঠিকানা সঠিক নয়");
  const raw = Array.isArray(body.items) ? body.items : [];
  if (!raw.length || raw.length > 30) throw new Error("কার্ট খালি বা অনেক বড়");

  const qtyByProduct = {}, lines = [];
  for (const it of raw) {
    const p = products.find(x => x && Number(x.id) === Number(it.productId));
    const q = Math.floor(Number(it.qty));
    if (!p || p.published === false || Object.values(settings.hiddenCats || {}).includes(p.category)) throw new Error("একটি পণ্য আর পাওয়া যাচ্ছে না");
    if (!(q >= 1 && q <= 50)) throw new Error("পরিমাণ সঠিক নয়");
    if (!available(p)) throw new Error(`“${p.name}” স্টকে নেই`);
    qtyByProduct[p.id] = (qtyByProduct[p.id] || 0) + q;
    if (hasQty(p) && qtyByProduct[p.id] > Number(p.stockQty)) throw new Error(`“${p.name}” এর পর্যাপ্ত স্টক নেই`);
    const vs = variantsOf(p), v = vs[Number(it.variantIndex)] || vs[0], price = finalPrice(v);
    if (!(price > 0)) throw new Error("পণ্যের দাম পাওয়া যায়নি");
    lines.push({ productId: p.id, name: p.name, size: v.size, qty: q, price, total: price * q });
  }
  const sub = lines.reduce((s, l) => s + l.total, 0);
  const fm = num(settings.freeDeliveryMin);
  const inside = body.area === "inside";
  const charge = (fm > 0 && sub >= fm) ? 0 : (inside ? num(settings.deliveryInside) : num(settings.deliveryOutside));
  const code = clean(body.coupon, 40).toUpperCase().replace(/[^A-Z0-9_-]/g, "");
  const cd = couponDiscount(code ? coupons[code] : null, sub);
  if (code && !coupons[code]) throw new Error("কুপন কোড সঠিক নয়");
  const grand = Math.max(0, sub - cd.amt) + charge;

  const pay0 = body.payment || {}, method = ["cod", "bkash", "nagad", "online"].includes(pay0.method) ? pay0.method : "cod";
  let payment = { method };
  if (method === "cod") {
    if (settings.advance === "delivery") throw new Error("অগ্রিম পেমেন্ট বাধ্যতামূলক");
  } else if (method === "online") {
    if (!(settings.onlinePayOn === true || settings.onlinePayOn === "true")) throw new Error("এই পেমেন্ট পদ্ধতি চালু নেই");
    payment = { method, plan: "full", advance: grand, sender: "", trxId: "", verified: false };
  } else {
    if (!settings[method]) throw new Error("এই পেমেন্ট পদ্ধতি চালু নেই");
    const plan = pay0.plan === "full" ? "full" : "delivery", advance = plan === "full" ? grand : charge;
    const sender = toEn(pay0.sender).replace(/\D/g, "").replace(/^88/, ""), trx = clean(pay0.trxId, 30).toUpperCase();
    if (advance > 0 && (!/^01[3-9]\d{8}$/.test(sender) || trx.length < 6)) throw new Error("পেমেন্টের তথ্য সঠিক নয়");
    payment = { method, plan, advance, sender, trxId: trx, verified: false };
  }
  return {
    status: "new", createdAt: Date.now(),
    customer: { name, phone, address, note }, items: lines,
    area: clean(body.areaName, 60) || (inside ? "ভিতরে" : "বাইরে"), subtotal: sub, discount: cd.amt, coupon: cd.amt ? code : "",
    deliveryCharge: charge, grandTotal: grand, payment, via: body.via === "whatsapp" ? "whatsapp" : "web", ...(body.terms === true ? { terms: true } : {}),
  };
};

exports.handler = async (event) => {
  const cors = corsHeaders(event);
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: { ...SEC, ...cors }, body: "" };
  if (event.httpMethod !== "POST") return json(405, { ok: false, error: "Method not allowed" }, cors);
  const allowed = process.env.ALLOWED_ORIGIN;
  if (allowed && event.headers.origin && event.headers.origin !== allowed) return json(403, { ok: false, error: "Forbidden" });
  const ip = (event.headers["x-nf-client-connection-ip"] || event.headers["x-forwarded-for"] || "").split(",")[0].trim() || "na";
  if (limited(ip)) return json(429, { ok: false, error: "অনেকবার চেষ্টা হয়েছে, কিছুক্ষণ পরে চেষ্টা করুন" }, cors);
  if ((event.body || "").length > 20000) return json(413, { ok: false, error: "অনুরোধ অনেক বড়" }, cors);
  let body; try { body = JSON.parse(event.body || "{}"); } catch (e) { return json(400, { ok: false, error: "ভুল অনুরোধ" }, cors); }
  try {
    init();
    const db = admin.database();
    const rid = String(body.rid || "").replace(/[^a-f0-9]/gi, "").slice(0, 40);
    // একই অনুরোধ আবার এলে নতুন অর্ডার নয় — আগেরটিই ফেরত
    if (rid) {
      const claim = await db.ref("orderRequests/" + rid).transaction(cur => cur === null ? { pending: true, at: Date.now() } : undefined);
      if (!claim.committed) {
        const ex = (await db.ref("orderRequests/" + rid).once("value")).val() || {};
        if (ex.orderId) { const od = (await db.ref("orders/" + ex.orderId).once("value")).val(); if (od) return json(200, { ok: true, order: od, duplicate: true }, cors); }
        return json(409, { ok: false, error: "আপনার অর্ডার প্রক্রিয়াধীন, একটু অপেক্ষা করুন" }, cors);
      }
    }
    const [pS, sS, cS] = await Promise.all([db.ref("products").once("value"), db.ref("settings").once("value"), db.ref("coupons").once("value")]);
    const products = Object.values(pS.val() || {}).filter(Boolean);
    let order;
    try { order = exports.buildOrder(body, products, sS.val() || {}, cS.val() || {}); }
    catch (e) { if (rid) await db.ref("orderRequests/" + rid).remove().catch(() => {}); throw e; }
    if (body.idToken) { try { order.uid = (await admin.auth().verifyIdToken(String(body.idToken))).uid; } catch (e) { /* অবৈধ টোকেন হলে গেস্ট অর্ডার */ } }
    if (body.visitor && typeof body.visitor === "object") order.visitor = { id: clean(body.visitor.id, 40), n: Math.min(999, Number(body.visitor.n) || 1), first: Number(body.visitor.first) || 0, src: clean(body.visitor.src, 60) };
    if (body.optIn === true) order.optIn = true;
    for (let i = 0; i < 5; i++) {
      order.id = makeId();
      const tx = await db.ref("orders/" + order.id).transaction(cur => cur === null ? order : undefined);
      if (tx.committed) {
        await db.ref("tracking/" + order.id).set({ status: "new", createdAt: order.createdAt, updatedAt: order.createdAt,
          phoneTail: order.customer.phone.slice(-4), phoneHash: crypto.createHash("sha256").update("ass:" + order.customer.phone).digest("hex"), grandTotal: order.grandTotal, productIds: order.items.map(i => i.productId), payMethod: order.payment.method });
        if (rid) await db.ref("orderRequests/" + rid).set({ orderId: order.id, at: Date.now() });
        return json(200, { ok: true, order }, cors);
      }
    }
    if (rid) await db.ref("orderRequests/" + rid).remove().catch(() => {});
    return json(500, { ok: false, error: "অর্ডার নম্বর তৈরি হয়নি, আবার চেষ্টা করুন" }, cors);
  } catch (e) {
    const known = /নাম|মোবাইল|ঠিকানা|কার্ট|পণ্য|স্টক|পরিমাণ|কুপন|পেমেন্ট|দাম|শর্ত|সম্মতি/.test(e.message);
    if (!known) console.error("place-order error", e);
    return json(known ? 400 : 500, { ok: false, error: known ? e.message : "সার্ভারে সমস্যা হয়েছে" }, cors);
  }
};

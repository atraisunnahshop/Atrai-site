// index.full.html  →  public/index.html (কাস্টমার, অ্যাডমিন কোড ছাড়া)  +  public/<ADMIN_FILE> (অ্যাডমিন পেজ)
const fs = require("fs"), path = require("path");
let acorn; try { acorn = require("acorn"); } catch (e) { acorn = require("/home/claude/.npm-global/lib/node_modules/ts-node/node_modules/acorn"); }
const ADMIN_FILE = process.argv[2], OUT = process.argv[3];
const html = fs.readFileSync(path.join(__dirname, "index.full.html"), "utf8");

function balancedDiv(h, startIdx) { // startIdx = "<div" এর শুরু
  let depth = 0, re = /<div\b|<\/div>/g; re.lastIndex = startIdx; let m;
  while ((m = re.exec(h))) { if (m[0] === "</div>") { depth--; if (depth === 0) return [startIdx, m.index + 6]; } else depth++; }
  throw new Error("unbalanced div");
}
const blocks = [];
for (const id of ["adminOverlay", "moOverlay"]) {
  const tag = html.match(new RegExp('<div class="modal-overlay" id="' + id + '"[^>]*>')); if (!tag) throw new Error("no " + id);
  blocks.push(balancedDiv(html, html.indexOf(tag[0])));
}
const adminHtml = blocks.map(([a, b]) => html.slice(a, b)).join("\n");
let storeHtml = html; blocks.sort((x, y) => y[0] - x[0]).forEach(([a, b]) => { storeHtml = storeHtml.slice(0, a) + storeHtml.slice(b); });

// ---- স্ক্রিপ্ট বিশ্লেষণ ----
const sm = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].pop(); const code = sm[1];
const ast = acorn.parse(code, { ecmaVersion: "latest", ranges: true });
const nodes = ast.body.map(n => {
  let names = [], kind = "stmt";
  if (n.type === "FunctionDeclaration") { names = [n.id.name]; kind = "fn"; }
  else if (n.type === "VariableDeclaration") { names = n.declarations.map(d => d.id.name).filter(Boolean); kind = "var"; if (!names.length) kind = "stmt"; }
  else if (n.type === "ClassDeclaration") { names = [n.id.name]; kind = "var"; }
  return { n, names, kind, text: code.slice(n.start, n.end) };
});
const byName = new Map(); nodes.forEach(x => x.names.forEach(nm => byName.set(nm, x)));
const allNames = [...byName.keys()];
const identRe = nm => new RegExp("(?<![\\w$])(?<!(?<!\\.)\\.)" + nm.replace(/\$/g, "\\$") + "(?![\\w$])");
function refsOf(text, self) { return allNames.filter(nm => !self.includes(nm) && identRe(nm).test(text)); }
nodes.forEach(x => { x.refs = refsOf(x.text, x.names); });

// অ্যাডমিন-বীজ: অ্যাডমিন HTML-এর হ্যান্ডলার
const adminSeed = new Set(refsOf(adminHtml, []).filter(nm => byName.get(nm).kind === "fn"));
["onAuth"].forEach(nm => adminSeed.delete(nm)); adminSeed.add("adminSide"); // onAuth দুই দিকেই লাগে; adminSide শুধু অ্যাডমিন
// অ্যাডমিন বন্ধ: বীজ থেকে পৌঁছানো সব
const RA = new Set(); (function walk(nm) { if (RA.has(nm)) return; RA.add(nm); const x = byName.get(nm); if (x) x.refs.forEach(walk); })._ = 0;
const stack = [...adminSeed]; while (stack.length) { const nm = stack.pop(); if (RA.has(nm)) continue; RA.add(nm); const x = byName.get(nm); if (x) x.refs.forEach(r => stack.push(r)); }
// স্টোরফ্রন্ট বীজ: কাস্টমার HTML + টপ-লেভেল স্টেটমেন্ট
const RS = new Set(); const q = [];
refsOf(storeHtml.replace(/<script>[\s\S]*?<\/script>/g, ""), []).forEach(nm => q.push([nm, true]));
nodes.filter(x => x.kind === "stmt").forEach(x => x.refs.forEach(nm => q.push([nm, true])));
while (q.length) { const [nm, direct] = q.pop(); if (RS.has(nm)) continue; if (!direct && adminSeed.has(nm)) continue; RS.add(nm); const x = byName.get(nm); if (x) x.refs.forEach(r => q.push([r, false])); }
const removable = new Set(); allNames.forEach(nm => { if (RA.has(nm) && !RS.has(nm)) removable.add(nm); });
// onAuth-এর মতো যে নোডে একাধিক নাম, সবগুলো সরানো গেলেই সরাও
const keepNodes = [], dropNodes = [];
nodes.forEach(x => { (x.names.length && x.names.every(nm => removable.has(nm))) ? dropNodes.push(x) : keepNodes.push(x); });
const dropped = new Set(dropNodes.flatMap(x => x.names));
// স্টাব: সরানো ফাংশন যা রাখা কোডে এখনো ডাকা হয়
const keptText = keepNodes.map(x => x.text).join("\n") + "\n" + storeHtml;
const stubs = [...dropped].filter(nm => byName.get(nm).kind === "fn" && identRe(nm).test(keptText));
function slices(list) { let out = "", prev = 0; for (const x of nodes) { const keep = list.includes(x); if (keep) out += code.slice(prev, x.n.end); prev = x.n.end; } return out; }
const storeCode = "/* স্টাব (অ্যাডমিন-ফাংশন এই পেজে নেই) */\n" + stubs.map(nm => `function ${nm}(){}`).join("\n") + "\n" + slices(keepNodes);
fs.writeFileSync("/tmp/build-report.txt", `admin seeds: ${adminSeed.size}\nremoved: ${dropped.size}\nstubs: ${stubs.length}\nkept bytes ${storeCode.length} of ${code.length}\n` + "removed names: " + [...dropped].join(",") + "\n\nstubs: " + stubs.join(","));

// ---- কাস্টমার পেজ ----
let store = storeHtml.replace(sm[0], () => "<script>" + storeCode + "</script>");
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, "index.html"), store);

// ---- অ্যাডমিন পেজ ----
let adminCode = code
  .replace("function cookieRefresh(){", "function cookieRefresh(){ return;")
  .replace("function maybeWelcome(){", "function maybeWelcome(){ return;")
  .replace("function loadPixel(", "function loadPixel(){ return; }\nfunction _lp(")
  .replace("function loadGTM(){", "function loadGTM(){ return;");
adminCode += `\n/* অ্যাডমিন পেজ */\ndocument.body.classList.add("admin-only");\nfunction closeAdmin(){ location.href = "/"; }\n(function(){ const o = document.getElementById("adminOverlay"); if (o) o.removeAttribute("onclick"); })();\nopenAdmin();\n`;
let admin = html.replace(sm[0], () => "<script>" + adminCode + "</script>")
  .replace(/<title>[\s\S]*?<\/title>/, "<title>ম্যানেজমেন্ট</title>\n<meta name=\"robots\" content=\"noindex,nofollow,noarchive\">")
  .replace(/<link rel="canonical"[^>]*>\s*/, "").replace(/<meta property="og:[^>]*>/g, "").replace(/<!-- Google Tag Manager \(noscript\) -->[\s\S]*?<!-- End Google Tag Manager \(noscript\) -->/, "").replace(/<meta name="description"[^>]*>/, "")
  .replace("</style>", "body.admin-only>*:not(#adminOverlay):not(#moOverlay):not(#toast):not(script){display:none!important}\nbody.admin-only{padding-bottom:0!important}\n</style>");
fs.writeFileSync(path.join(OUT, ADMIN_FILE), admin);

// ---- মধুর আলাদা পেজ (/honey) ----
const honeySection = `<section class="section honey-hero" id="honeyHero"><div class="wrap">
  <div class="kicker">আত্রাই, নওগাঁ</div>
  <h1>মধু — আত্রাই সুন্নাহ্ শপ</h1>
  <p>বিভিন্ন ধরনের মধু এক জায়গায়। নিচে প্রতিটি মধুর সাইজ, দাম ও স্টক দেখে ঘরে বসে অর্ডার করুন।</p>
  <div class="hn-chips"><span>🚚 ক্যাশ অন ডেলিভারি</span><span>📍 ডেলিভারি চার্জ অর্ডারের আগেই জানানো হয়</span><span>🔎 অর্ডারের পর নম্বর দিয়ে ট্র্যাক করা যায়</span></div>
  <div class="hn-cta"><a class="btn btn-gold" href="#products">মধু দেখুন ও অর্ডার করুন</a><a class="btn btn-wa" id="hnWa" target="_blank" rel="noopener" href="https://wa.me/8801779231573">WhatsApp-এ জিজ্ঞাসা করুন</a></div>
</div></section>`;
const honeyInfo = `<section class="section" id="hnInfo"><div class="wrap policy">
  <div class="section-head"><div class="kicker">অর্ডার ও ডেলিভারি</div><h2>অর্ডার করার আগে জেনে নিন</h2></div>
  <ul><li><b>পেমেন্ট:</b> ক্যাশ অন ডেলিভারি; bKash/Nagad ম্যানুয়াল পেমেন্ট (চালু থাকলে অর্ডার ফর্মে দেখাবে)।</li>
  <li><b>ডেলিভারি চার্জ:</b> <span id="hnCharges"></span></li>
  <li><b>অর্ডার সংরক্ষণ:</b> অর্ডার সফলভাবে সংরক্ষিত হলে তবেই অর্ডার নম্বর দেখানো হয়; WhatsApp মেসেজ তৈরি হওয়া অর্ডার সংরক্ষণ নয়।</li>
  <li><b>পণ্য হাতে পেয়ে:</b> প্যাকেট খুলে নাম, ওজন ও অবস্থা দেখে নিন; সমস্যা হলে ছবি/ভিডিওসহ জানান — <a href="javascript:void(0)" onclick="openPage('return')">ফেরত নীতিমালা</a>।</li></ul>
  <div class="section-head" style="margin-top:26px"><div class="kicker">সাধারণ প্রশ্ন</div><h2>মধু নিয়ে প্রশ্নোত্তর</h2></div>
  <details><summary>মধুর দাম ও ওজন কোথায় দেখব?</summary><p>প্রতিটি পণ্যের কার্ডে সাইজ বেছে নিলে সেই সাইজের দাম দেখা যায়। স্টক শেষ হলে অর্ডার বাটন বন্ধ থাকে।</p></details>
  <details><summary>কীভাবে অর্ডার করব?</summary><p>সাইজ বেছে "ব্যাগে যোগ করুন" বা "এখনই কিনুন" চাপুন। নাম, মোবাইল নম্বর ও ঠিকানা দিয়ে শর্তাবলিতে টিক দিয়ে অর্ডার কনফার্ম করুন।</p></details>
  <details><summary>ক্যাশ অন ডেলিভারি আছে কি?</summary><p>হ্যাঁ, ক্যাশ অন ডেলিভারি চালু আছে (কোনো সময় অগ্রিম পেমেন্ট চালু থাকলে অর্ডার ফর্মে জানানো হবে)।</p></details>
  <details><summary>মধু জমে গেলে বা দানা বাঁধলে কী করব?</summary><p>প্রাকৃতিক পণ্যে মৌসুম ও পরিবেশভেদে এমন পার্থক্য দেখা যায় বলে আমাদের নীতিমালায় উল্লেখ আছে। সন্দেহ হলে ছবিসহ আমাদের জানান — বিস্তারিত <a href="javascript:void(0)" onclick="openPage('return')">ফেরত নীতিমালায়</a>।</p></details>
  <details><summary>ভুল বা ক্ষতিগ্রস্ত পণ্য পেলে কী করব?</summary><p>৩–৫ কার্যদিবসের মধ্যে অর্ডার নম্বর ও ছবি/ভিডিওসহ WhatsApp বা ফোনে জানান; যাচাই করে সমাধান দেওয়া হবে।</p></details>
  <details><summary>অর্ডারের অবস্থা কীভাবে জানব?</summary><p>উপরের "অর্ডার ট্র্যাক" বাটনে মোবাইল নম্বর, অর্ডার নম্বর বা কুরিয়ারের ট্র্যাকিং নম্বর দিন।</p></details>
</div></section>`;
const honeyCss = `body.honey-page #bnWrap,body.honey-page #home,body.honey-page #trustSec,body.honey-page #tilesSec,body.honey-page #about,body.honey-page #filterButtons{display:none!important}
.honey-hero{background:var(--cream);padding-top:34px}.honey-hero h1{margin:6px 0 8px;font-size:clamp(26px,5vw,40px);color:var(--green);font-family:"Noto Serif Bengali","Noto Sans Bengali","Kalpurush","Nirmala UI",serif}
.honey-hero p{max-width:640px;margin:0 0 14px;font-size:16px}.hn-chips{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.hn-chips span{background:#fff;border:1px solid var(--line);border-radius:999px;padding:6px 12px;font-size:13.5px}
.hn-cta{display:flex;gap:10px;flex-wrap:wrap}`;
const honeyJs = `<script>
/* /honey পেজ: শুধু মধু ক্যাটাগরি, SEO ডেটা (মূল্য/স্টক ছাড়া কোনো বানানো রেটিং নয়) */
state.cat = "honey";
function honeyLD(){
  try {
    const abs = u => /^https?:/.test(u) ? u : "https://atraisunnahshop.com/" + String(u || "").replace(/^\\/+/, "");
    const items = visible().filter(p => p.category === "honey").slice(0, 30).map(p => { const v = variantsOf(p)[0]; const o = { "@type":"Product", name:p.name, offers:{ "@type":"Offer", priceCurrency:"BDT", price:String(finalPrice(v)), availability: available(p) ? "https://schema.org/InStock" : "https://schema.org/OutOfStock", url:"https://atraisunnahshop.com/honey" } }; if (p.images && p.images[0] && !/^data:/.test(p.images[0])) o.image = abs(p.images[0]); if (p.desc) o.description = String(p.desc).slice(0, 200); return o; });
    let el = document.getElementById("ldHoney"); if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = "ldHoney"; document.head.appendChild(el); }
    el.textContent = JSON.stringify({ "@context":"https://schema.org", "@type":"ItemList", itemListElement: items.map((x, i) => ({ "@type":"ListItem", position:i + 1, item:x })) });
  } catch(e) {}
}
function fillHoney(){ const c = document.getElementById("hnCharges"); if (c) c.textContent = chargesText(); const w = document.getElementById("hnWa"); if (w) w.href = waLink("আসসালামু আলাইকুম, আমি মধু সম্পর্কে জানতে চাই।"); }
const _rg0 = renderGrid; renderGrid = function(){ _rg0(); honeyLD(); fillHoney(); };
const _as0 = applySettings; applySettings = function(){ _as0(); fillHoney(); };
</script>`;
let honey = store
  .replace(/<title>[\s\S]*?<\/title>/, "<title>মধু — আত্রাই সুন্নাহ্ শপ | আত্রাই, নওগাঁ</title>")
  .replace(/<meta name="description"[^>]*>/, '<meta name="description" content="আত্রাই সুন্নাহ্ শপ থেকে বিভিন্ন ধরনের মধু — সাইজ, দাম ও স্টক দেখে অর্ডার করুন। ক্যাশ অন ডেলিভারি ও WhatsApp-এ যোগাযোগ।">')
  .replace(/<link rel="canonical"[^>]*>/, '<link rel="canonical" href="https://atraisunnahshop.com/honey">')
  .replace(/<meta property="og:url"[^>]*>/, '<meta property="og:url" content="https://atraisunnahshop.com/honey">')
  .replace(/<meta property="og:title"[^>]*>/, '<meta property="og:title" content="মধু — আত্রাই সুন্নাহ্ শপ">')
  .replace(/<body([^>]*)>/, (m, a) => '<body' + (/class="/.test(a) ? a.replace('class="', 'class="honey-page ') : a + ' class="honey-page"') + '>')
  .replace('<div id="cbTop"></div>', '<div id="cbTop"></div>\n' + honeySection)
  .replace('<div id="cbBottom"></div>', '<div id="cbBottom"></div>')
  .replace('<section class="section" id="how"', honeyInfo + '\n<section class="section" id="how"')
  .replace('</style>', honeyCss + '\n</style>')
  .replace(/<\/body>/, honeyJs + '\n</body>');
fs.writeFileSync(path.join(OUT, "honey.html"), honey);

// ---- ৪০৪, সাইটম্যাপ, robots, হেডার, রিডাইরেক্ট ----
const today = new Date().toISOString().slice(0, 10);
fs.writeFileSync(path.join(OUT, "404.html"), `<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>পেজ পাওয়া যায়নি — আত্রাই সুন্নাহ্ শপ</title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;600;700&display=swap" rel="stylesheet"><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#fbf7ed;font-family:"Hind Siliguri","Noto Sans Bengali","Kalpurush","Nirmala UI",sans-serif;color:#1d2a23;text-align:center;padding:24px}h1{color:#163d2b;margin:0 0 8px}a{display:inline-block;margin:6px;padding:10px 18px;border-radius:999px;background:#163d2b;color:#fff;text-decoration:none;font-weight:600}a.g{background:#d5a84f;color:#1d2a23}</style></head><body><div><div style="font-size:54px">🌿</div><h1>দুঃখিত, পেজটি পাওয়া যায়নি</h1><p>লিংকটি ভুল হতে পারে বা পেজটি সরানো হয়েছে।</p><a href="/">হোমপেজে যান</a><a class="g" href="/honey">মধু দেখুন</a></div></body></html>`);
fs.writeFileSync(path.join(OUT, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>https://atraisunnahshop.com/</loc><lastmod>${today}</lastmod><priority>1.0</priority></url>\n  <url><loc>https://atraisunnahshop.com/honey</loc><lastmod>${today}</lastmod><priority>0.9</priority></url>\n</urlset>\n`);
fs.writeFileSync(path.join(OUT, "robots.txt"), "User-agent: *\nAllow: /\nSitemap: https://atraisunnahshop.com/sitemap.xml\n");
const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline' https://www.gstatic.com https://www.googletagmanager.com https://connect.facebook.net https://www.google-analytics.com https://apis.google.com; connect-src 'self' https://*.firebaseio.com wss://*.firebaseio.com https://*.firebasedatabase.app wss://*.firebasedatabase.app https://identitytoolkit.googleapis.com https://securetoken.googleapis.com https://www.googleapis.com https://formspree.io https://*.google-analytics.com https://www.googletagmanager.com https://www.facebook.com https://connect.facebook.net; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; frame-src https://www.googletagmanager.com https://*.firebaseapp.com https://www.facebook.com; base-uri 'self'; form-action 'self' https://formspree.io; object-src 'none'";
fs.writeFileSync(path.join(OUT, "_headers"), `/*\n  X-Content-Type-Options: nosniff\n  X-Frame-Options: SAMEORIGIN\n  Referrer-Policy: strict-origin-when-cross-origin\n  Permissions-Policy: camera=(), microphone=(), geolocation=()\n  Strict-Transport-Security: max-age=31536000\n  Content-Security-Policy-Report-Only: ${CSP}\n/images/*\n  Cache-Control: public, max-age=604800\n`);
fs.writeFileSync(path.join(OUT, "_redirects"), `/honey /honey.html 200\n/honey/ /honey.html 200\nhttps://atraisunnahshop.netlify.app/* https://atraisunnahshop.com/:splat 301!\n`);

console.log(fs.readFileSync("/tmp/build-report.txt", "utf8").split("\n").slice(0, 4).join("\n"));

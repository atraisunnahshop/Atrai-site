# উৎস ফাইল (শুধু ডেভেলপারের জন্য — প্রকাশ হয় না)
`index.full.html` — পুরো অ্যাপ (কাস্টমার + অ্যাডমিন একসাথে)। `build.js` এটি থেকে দুই পেজ + মধুর পেজ + sitemap/robots/404/_headers/_redirects তৈরি করে।

পরিবর্তনের পর (Node.js ১৮+):
```
cd _source
npm install
node build.js "ams-8ixfqfxau0.html" ../public
```
এই ফোল্ডারটি একটি **প্রাইভেট** GitHub রিপোতে রাখুন (এতে অ্যাডমিন কোড আছে)। Netlify-র `publish` শুধু `public/`।
